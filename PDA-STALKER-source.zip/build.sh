#!/usr/bin/env bash
# Сборка APK без Gradle: aapt2 + javac + d8 + apksigner
set -euo pipefail
cd "$(dirname "$0")"
SDK="${ANDROID_HOME:-$HOME/android-sdk}"
BT="$SDK/build-tools/36.1.0"
JAR="$SDK/platforms/android-36/android.jar"
OUT=build
rm -rf "$OUT" && mkdir -p "$OUT"/{res,gen,classes,dex}

"$BT/aapt2" compile --dir res -o "$OUT/res/compiled.zip"
"$BT/aapt2" link -o "$OUT/unsigned.apk" -I "$JAR" --manifest AndroidManifest.xml \
  -A assets --java "$OUT/gen" "$OUT/res/compiled.zip" --auto-add-overlay
javac -source 11 -target 11 -nowarn -encoding UTF-8 -classpath "$JAR" -d "$OUT/classes" \
  $(find src "$OUT/gen" -name '*.java') 2>&1 | grep -v "bootstrap classpath" || true
"$BT/d8" --release --min-api 26 --lib "$JAR" --output "$OUT/dex" $(find "$OUT/classes" -name '*.class')
(cd "$OUT/dex" && zip -q ../unsigned.apk classes.dex)
"$BT/zipalign" -f -p 4 "$OUT/unsigned.apk" "$OUT/aligned.apk"

KS="${PDA_KEYSTORE:-pda-release.jks}"
if [ ! -f "$KS" ]; then
  keytool -genkeypair -keystore "$KS" -alias pda -keyalg RSA -keysize 2048 -validity 10000 \
    -storepass stalker -keypass stalker -dname "CN=PDA Stalker, O=Zone, C=UA"
fi
"$BT/apksigner" sign --ks "$KS" --ks-pass pass:stalker --key-pass pass:stalker \
  --out "$OUT/PDA-STALKER.apk" "$OUT/aligned.apk"
"$BT/apksigner" verify "$OUT/PDA-STALKER.apk"
ls -lh "$OUT/PDA-STALKER.apk"
