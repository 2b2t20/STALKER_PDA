(function () {
'use strict';

var KEY = 'pda_stalker_v2';
var NATIVE = window.AndroidPDA || null;

/* ============ Справочники ============ */
var TABS = [
  { id: 'tasks', name: 'Задачи' }, { id: 'plan', name: 'План' }, { id: 'journal', name: 'Журнал' },
  { id: 'contacts', name: 'Контакты' }, { id: 'ranks', name: 'Ранги' }, { id: 'data', name: 'Данные' }, { id: 'help', name: 'Справка' }
];
var LOCS = [
  { id: 'kordon', name: 'Кордон', x: 267, y: 224 }, { id: 'svalka', name: 'Свалка', x: 260, y: 180 },
  { id: 'agroprom', name: 'Агропром', x: 137, y: 177 }, { id: 'dolina', name: 'Тёмная долина', x: 389, y: 184 },
  { id: 'bar', name: 'Бар «100 рентген»', x: 254, y: 140 }, { id: 'dikaya', name: 'Дикая территория', x: 176, y: 126 },
  { id: 'yantar', name: 'Янтарь', x: 86, y: 112 }, { id: 'sklady', name: 'Армейские склады', x: 291, y: 100 },
  { id: 'radar', name: 'Радар', x: 280, y: 70 }, { id: 'pripyat', name: 'Припять', x: 240, y: 41 }, { id: 'chaes', name: 'ЧАЭС', x: 358, y: 30 }
];
var ROADS = [['kordon','svalka'],['svalka','agroprom'],['svalka','dolina'],['svalka','bar'],['bar','dikaya'],['dikaya','yantar'],['bar','sklady'],['sklady','radar'],['radar','pripyat'],['pripyat','chaes'],['agroprom','dikaya']];
var FACTIONS = ['Одиночки','Долг','Свобода','Учёные','Военные','Бандиты','Наёмники','Монолит','Торговцы'];
var ROLES = ['Сталкер','Торговец','Учёный','Проводник','Военный','Бандит','Механик','Информатор'];
var RELS = { friend: 'Друг', neutral: 'Нейтрал', enemy: 'Враг' };
var JCATS = ['Событие','Наблюдение','Аномалия','Артефакт','Мутант','Личное','Система'];
var PRIO = { high: 'Высокий', mid: 'Средний', low: 'Низкий' };
var XP_BY_PRIO = { high: 200, mid: 100, low: 50 };
var RANKS = [
  { name: 'Новичок', xp: 0, ico: 'I', desc: 'Только пришёл в Зону.' },
  { name: 'Опытный', xp: 300, ico: 'II', desc: 'Пару ходок пережил.' },
  { name: 'Ветеран', xp: 1000, ico: 'III', desc: 'Знают на Кордоне и в Баре.' },
  { name: 'Мастер', xp: 2500, ico: 'IV', desc: 'Ходит туда, куда другие боятся.' },
  { name: 'Легенда', xp: 5000, ico: 'V', desc: 'О нём рассказывают у костра.' }
];
var NPC_RATING = [
  ['Призрак','Одиночки',6400],['Клык','Одиночки',5200],['Генерал Воронин','Долг',4800],['Лукаш','Свобода',4500],
  ['Доктор','Одиночки',4100],['Бармен','Торговцы',3600],['Профессор Сахаров','Учёные',3000],['Петренко','Долг',2400],
  ['Волк','Одиночки',1900],['Шустрый','Одиночки',1400],['Борров','Бандиты',1200],['Лис','Одиночки',800],
  ['Толик','Одиночки',450],['Серый','Бандиты',380],['Шныга','Одиночки',260],['Кривой','Бандиты',120]
];
var HELP = [
  { id: 'start', t: 'Начало работы', h: '<p>КПК сталкера — персональный помощник в Зоне. Все записи хранятся только на этом устройстве, интернет не нужен.</p><p>Разделы переключаются на нижней панели: <span class="k">Задачи // План // Журнал // Контакты // Ранги // Данные // Справка</span>. Слева — список, справа — карта или подробности.</p>' },
  { id: 'tasks', t: 'Задачи', h: '<p>У задания есть этапы (кружки под названием). Нажми на этап, чтобы отметить его выполненным.</p><ul><li><b>Сдать</b> — опыт 50/100/200 по приоритету, награда в RU и +5 к репутации.</li><li><b>Провал</b> — −10 к репутации.</li><li>Внизу окна — фильтр: Активные, Выполненные, Проваленные.</li><li>Справа — карта: задания отмечены зелёными метками, нажми на табличку для полного описания.</li></ul>' },
  { id: 'plan', t: 'План', h: '<p>Маршрут по Зоне. Нажми на локацию на карте — можно добавить точку или отметить «Я здесь». Карту можно двигать пальцем и приближать кнопками <b>+</b> и <b>−</b>.</p>' },
  { id: 'journal', t: 'Журнал', h: '<p>Дневник: события, наблюдения, аномалии, артефакты. Выполненные задания и переходы между локациями записываются автоматически (категория «Система»).</p>' },
  { id: 'contacts', t: 'Контакты', h: '<p>Сталкеры, торговцы, знакомые. Цвет рамки портрета: зелёный — друг, жёлтый — нейтрал, красный — враг.</p>' },
  { id: 'ranks', t: 'Ранги', h: '<p>Звания: Новичок → Опытный (300) → Ветеран (1000) → Мастер (2500) → Легенда (5000). Слева — рейтинг сталкеров, твоя строка подсвечена. Справа — личное дело и отношения группировок.</p>' },
  { id: 'data', t: 'Данные', h: '<p>Статистика, резервные копии (сохранить файл, поделиться, загрузить) и настройки.</p>' },
  { id: 'hw', t: 'Кнопки корпуса', h: '<ul><li><b class="red">Красная трубка</b> — назад / закрыть окно.</li><li><b class="green">Зелёная трубка</b> — новая запись в текущем разделе.</li><li><b>Джойстик</b> ▲▼ — выбор в списке, ◀▶ — смена раздела, центр — изменить выбранное (в задачах — отметить следующий этап).</li><li><b>Квадратные кнопки</b> — звук и выключение КПК. Объектив слева тоже выключает КПК.</li></ul>' },
  { id: 'about', t: 'О приложении', h: '<p><b>PDA S.T.A.L.K.E.R.</b> v3.0 — фанатский КПК в стиле S.T.A.L.K.E.R.: Тень Чернобыля. Горизонтальная версия, Android 8–16.</p><p class="dim">Некоммерческий проект. S.T.A.L.K.E.R. — торговая марка GSC Game World.</p>' }
];

/* ============ Состояние ============ */
var S, ui = { tab: 'tasks', sel: {}, taskFilter: 'active', jq: '', jf: '', crel: '', help: 'start', map: { z: 1, x: 0, y: 0 } };
function uid() { return Date.now().toString(36) + Math.random().toString(36).slice(2, 7); }
function now() { return Date.now(); }
function todayISO() { var d = new Date(); d.setMinutes(d.getMinutes() - d.getTimezoneOffset()); return d.toISOString().slice(0, 10); }
function st(t, d) { return { t: t, done: !!d }; }

function seed() {
  var t = now();
  return {
    v: 3, created: t,
    profile: { callsign: 'Меченый', faction: 'Одиночки', xp: 0, rep: 0, money: 1500, loc: 'kordon',
      rel: { 'Одиночки': 60, 'Долг': 10, 'Свобода': 10, 'Учёные': 30, 'Военные': -40, 'Бандиты': -70, 'Наёмники': -30, 'Монолит': -100, 'Торговцы': 40 } },
    tasks: [
      { id: uid(), title: 'Найти Артефакт.', desc: 'Волк просил найти артефакт «Медуза» возле аномалий у железнодорожной насыпи и отнести Сидоровичу.', loc: 'kordon', reward: 500, prio: 'mid', status: 'active', created: t,
        steps: [st('Поговорить с Волком.', 1), st('Найти Артефакт Медуза.'), st('Отнести Артефакт Сидоровичу.')] },
      { id: uid(), title: 'Найти 10 консерв «Радость Туриста».', desc: 'Волку нужны консервы для лагеря новичков.', loc: 'kordon', reward: 300, prio: 'low', status: 'active', created: t - 4e5,
        steps: [st('Найти 10 консерв.'), st('Отдать 10 консерв Волку.')] },
      { id: uid(), title: 'Забрать информацию у разведчика', desc: 'Сидорович просил забрать флешку у бандитов на АТП. Осторожно — их там человек пять.', loc: 'kordon', reward: 1500, prio: 'high', status: 'active', created: t - 8e5,
        steps: [st('Поговорить с Волком', 1), st('Встретиться с людьми Волка'), st('Забрать флешку на АТП')] },
      { id: uid(), title: 'Убить Стрелка', desc: 'Единственная запись в КПК после аварии. Кто такой Стрелок и почему его нужно убить — неизвестно.', loc: 'chaes', reward: 0, prio: 'high', status: 'active', created: t - 1e7, steps: [] }
    ],
    plans: [
      { id: uid(), title: 'Лагерь новичков', loc: 'kordon', date: todayISO(), time: '08:00', note: 'Закупиться у Сидоровича', done: false },
      { id: uid(), title: 'Мост через насыпь', loc: 'svalka', date: todayISO(), time: '11:00', note: 'Обойти аномалии слева', done: false },
      { id: uid(), title: 'Бар «100 рентген»', loc: 'bar', date: todayISO(), time: '16:00', note: 'Поговорить с Барменом', done: false }
    ],
    journal: [
      { id: uid(), title: 'Очнулся у Сидоровича', cat: 'Событие', date: t - 2e7, text: 'Грузовик смерти перевернулся во время грозы. Меня нашёл сталкер и притащил к торговцу. В КПК одна запись: «Убить Стрелка». Больше ничего не помню.' },
      { id: uid(), title: 'Аномалия «Трамплин» у тоннеля', cat: 'Аномалия', date: t - 1.2e7, text: 'Под железнодорожным мостом целое поле гравитационных аномалий. Бросать болты, идти медленно.' }
    ],
    contacts: [
      { id: uid(), name: 'Сидорович', faction: 'Торговцы', role: 'Торговец', rel: 'neutral', loc: 'kordon', note: 'Бункер в деревне новичков. Скупает артефакты, даёт задания.' },
      { id: uid(), name: 'Волк', faction: 'Одиночки', role: 'Сталкер', rel: 'friend', loc: 'kordon', note: 'Главный в лагере новичков. Надёжный мужик.' },
      { id: uid(), name: 'Шустрый', faction: 'Одиночки', role: 'Информатор', rel: 'friend', loc: 'svalka', note: 'Знает про Стрелка.' },
      { id: uid(), name: 'Бармен', faction: 'Торговцы', role: 'Торговец', rel: 'neutral', loc: 'bar', note: 'Хозяин «100 рентген».' },
      { id: uid(), name: 'Профессор Сахаров', faction: 'Учёные', role: 'Учёный', rel: 'neutral', loc: 'yantar', note: 'Бункер учёных на Янтаре.' },
      { id: uid(), name: 'Борров', faction: 'Бандиты', role: 'Бандит', rel: 'enemy', loc: 'dolina', note: 'Главарь бандитов Тёмной долины.' }
    ],
    settings: { sound: true, vibro: true, boot: true }
  };
}
function normalize(d) {
  var base = seed(); d = d || {};
  ['tasks', 'plans', 'journal', 'contacts'].forEach(function (k) { if (!Array.isArray(d[k])) d[k] = []; });
  d.tasks.forEach(function (t) { if (!Array.isArray(t.steps)) t.steps = []; });
  d.profile = Object.assign({}, base.profile, d.profile || {});
  d.profile.rel = Object.assign({}, base.profile.rel, (d.profile && d.profile.rel) || {});
  d.settings = Object.assign({}, base.settings, d.settings || {});
  d.created = d.created || now(); d.v = 3;
  return d;
}
function load() {
  try { var raw = localStorage.getItem(KEY); if (raw) { S = normalize(JSON.parse(raw)); return; } } catch (e) {}
  S = seed(); save();
}
function save() { try { localStorage.setItem(KEY, JSON.stringify(S)); } catch (e) { toast('Ошибка памяти', 'Не удалось сохранить', 'r'); } }

/* ============ Утилиты ============ */
function $(s, r) { return (r || document).querySelector(s); }
function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
function loc(id) { for (var i = 0; i < LOCS.length; i++) if (LOCS[i].id === id) return LOCS[i]; return LOCS[0]; }
function locName(id) { return loc(id).name; }
function find(a, id) { for (var i = 0; i < a.length; i++) if (a[i].id === id) return a[i]; return null; }
function pad(n) { return (n < 10 ? '0' : '') + n; }
function fmtD(ts) { var d = new Date(ts); return pad(d.getDate()) + '/' + pad(d.getMonth() + 1) + '/' + d.getFullYear(); }
function fmtDT(ts) { var d = new Date(ts); return fmtD(ts) + ' ' + pad(d.getHours()) + ':' + pad(d.getMinutes()); }
function fmtISO(iso) { if (!iso) return ''; var p = iso.split('-'); return p.length === 3 ? p[2] + '/' + p[1] + '/' + p[0] : iso; }
function money(n) { return (Number(n) || 0).toLocaleString('ru-RU') + ' RU'; }
function rankIdx(xp) { var r = 0; for (var i = 0; i < RANKS.length; i++) if (xp >= RANKS[i].xp) r = i; return r; }
function repLabel(r) { return r >= 60 ? 'Отличная' : r >= 25 ? 'Хорошая' : r > -25 ? 'Нейтральная' : r > -60 ? 'Плохая' : 'Ужасная'; }
function relLabel(v) { return v >= 50 ? 'Друзья' : v >= 15 ? 'Хорошие' : v > -15 ? 'Нейтралы' : v > -50 ? 'Неприязнь' : 'Враги'; }
function relCls(v) { return v >= 15 ? 'green' : v > -15 ? 'yellow' : 'red'; }

var IC = {
  plus: '<path d="M12 5v14M5 12h14"/>', check: '<path d="M5 12.5l4.5 4.5L19 7"/>', cross: '<path d="M6 6l12 12M18 6L6 18"/>',
  edit: '<path d="M4 20h4L19 9l-4-4L4 16z"/>', trash: '<path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13"/>',
  up: '<path d="M6 15l6-6 6 6"/>', down: '<path d="M6 9l6 6 6-6"/>', zin: '<circle cx="10" cy="10" r="6"/><path d="M15 15l5 5M7.5 10h5M10 7.5v5"/>',
  zout: '<circle cx="10" cy="10" r="6"/><path d="M15 15l5 5M7.5 10h5"/>', here: '<circle cx="12" cy="12" r="3"/><circle cx="12" cy="12" r="8"/><path d="M12 1v3M12 20v3M1 12h3M20 12h3"/>',
  fit: '<path d="M4 9V4h5M15 4h5v5M20 15v5h-5M9 20H4v-5"/>', info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7.5v.5"/>'
};
function ico(n) { return '<svg viewBox="0 0 24 24">' + IC[n] + '</svg>'; }
function tb(act, icon, label, cls, data, dis) {
  return '<button class="tb ' + (cls || '') + '" data-act="' + act + '"' + (data || '') + (dis ? ' disabled' : '') + ' title="' + esc(label || '') + '">' + ico(icon) + (label ? '<span>' + esc(label) + '</span>' : '') + '</button>';
}
var TGT = '<svg viewBox="0 0 20 20" width="20" height="20"><circle cx="10" cy="10" r="7" fill="#123d10" stroke="#5be04a" stroke-width="1.4"/><circle cx="10" cy="10" r="3" fill="none" stroke="#c8ffb8" stroke-width="1.2"/><path d="M10 1.5v4M10 14.5v4M1.5 10h4M14.5 10h4" stroke="#c8ffb8" stroke-width="1.2"/></svg>';
var TGT_GREY = '<svg viewBox="0 0 20 20" width="20" height="20"><circle cx="10" cy="10" r="7" fill="none" stroke="#8d8e92" stroke-width="1.4"/><circle cx="10" cy="10" r="3" fill="none" stroke="#8d8e92" stroke-width="1.2"/><path d="M10 1.5v4M10 14.5v4M1.5 10h4M14.5 10h4" stroke="#8d8e92" stroke-width="1.2"/></svg>';
var TGT_RED = '<svg viewBox="0 0 20 20" width="20" height="20"><circle cx="10" cy="10" r="7" fill="#5a1410" stroke="#ff5040" stroke-width="1.4"/><circle cx="10" cy="10" r="2.6" fill="#ff8070"/></svg>';
var SCROLLICO = '<svg viewBox="0 0 20 20"><path d="M5 3H3v14h2M15 3h2v14h-2M7 6h6M7 10h6M7 14h6" fill="none" stroke="#a0a1a6" stroke-width="1.3"/></svg>';
function portrait(seedStr, cls) {
  var h = 0; for (var i = 0; i < seedStr.length; i++) h = (h * 31 + seedStr.charCodeAt(i)) >>> 0;
  var hood = ['#2a2b2f', '#33302a', '#2b322a', '#2f2a2a', '#262a30'][h % 5], mask = h % 3 === 0;
  var face = mask ? '<ellipse cx="20" cy="23" rx="7" ry="8.5" fill="#1a1b1d"/><circle cx="17" cy="21" r="2.2" fill="#77888c"/><circle cx="23" cy="21" r="2.2" fill="#77888c"/><circle cx="20" cy="28" r="2.6" fill="#3d3e43"/>'
    : '<ellipse cx="20" cy="23" rx="6.5" ry="8" fill="#8a7a6a"/><ellipse cx="20" cy="26" rx="6" ry="4" fill="#6a5a4c" opacity=".6"/><rect x="15" y="20" width="3" height="1.3" fill="#222"/><rect x="22" y="20" width="3" height="1.3" fill="#222"/>';
  return '<div class="portrait ' + (cls || '') + '"><svg viewBox="0 0 40 50" preserveAspectRatio="xMidYMax slice"><path d="M-2 52V43Q3 35 13 33h14q10 2 15 10v9z" fill="' + hood + '"/>' +
    '<path d="M10 31Q7 12 20 7q13 5 10 24-4 4-10 4t-10-4z" fill="' + hood + '"/>' + face + '<path d="M10 31Q7 12 20 7q13 5 10 24" fill="none" stroke="rgba(255,255,255,.08)"/></svg></div>';
}

/* ============ Текстура карты (спутниковый снимок) ============ */
var TERRAIN = '';
function makeTerrain() {
  var W = 960, H = 500, c = document.createElement('canvas'); c.width = W; c.height = H;
  var x = c.getContext('2d'), s = 1986;
  function rnd() { s |= 0; s = s + 0x6D2B79F5 | 0; var t = Math.imul(s ^ s >>> 15, 1 | s); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }
  x.fillStyle = '#3a3833'; x.fillRect(0, 0, W, H);
  var pal = ['#4a463d', '#2f2d29', '#3d4433', '#55503f', '#262522', '#46493b', '#5b5546', '#333a2c', '#4d4a44'];
  for (var i = 0; i < 650; i++) {
    x.globalAlpha = .18 + rnd() * .35; x.fillStyle = pal[(rnd() * pal.length) | 0];
    x.beginPath(); x.ellipse(rnd() * W, rnd() * H, 8 + rnd() * 70, 6 + rnd() * 50, rnd() * 3.14, 0, 6.29); x.fill();
  }
  x.globalAlpha = .5; x.strokeStyle = '#25231f'; x.lineWidth = 2;
  for (var k = 0; k < 40; k++) { var a = rnd() * W, b = rnd() * H; x.strokeRect(a, b, 6 + rnd() * 14, 5 + rnd() * 10); }
  x.globalAlpha = 1;
  var c2 = document.createElement('canvas'); c2.width = W; c2.height = H; var y = c2.getContext('2d');
  y.filter = 'blur(3px)'; y.drawImage(c, 0, 0); y.filter = 'none';
  var img = y.getImageData(0, 0, W, H), d = img.data;
  for (var p = 0; p < d.length; p += 4) { var n = (rnd() - .5) * 22; d[p] += n; d[p + 1] += n; d[p + 2] += n; }
  y.putImageData(img, 0, 0);
  y.globalAlpha = .35; y.fillStyle = '#5a2a1a'; y.beginPath(); y.ellipse(716, 60, 120, 70, 0, 0, 6.29); y.fill();
  try { TERRAIN = c2.toDataURL('image/jpeg', .82); } catch (e) { TERRAIN = ''; }
}
function thumbStyle(locId) {
  var l = loc(locId);
  return 'background-image:url(' + TERRAIN + ');background-size:520% auto;background-position:' + (l.x / 480 * 100).toFixed(1) + '% ' + (l.y / 250 * 100).toFixed(1) + '%';
}

/* ============ Звук / вибрация ============ */
var actx = null;
function beep(type) {
  if (S && S.settings.vibro && NATIVE) { try { NATIVE.vibrate(type === 'err' ? 60 : 12); } catch (e) {} }
  if (!S || !S.settings.sound) return;
  try {
    actx = actx || new (window.AudioContext || window.webkitAudioContext)();
    if (actx.state === 'suspended') actx.resume();
    var seq = type === 'note' ? [[988, .08], [1319, .12]] : type === 'err' ? [[200, .15]] : type === 'ok' ? [[740, .05], [1108, .08]] : type === 'boot' ? [[523, .07], [784, .07], [1046, .14]] : [[2200, .018]];
    var t = actx.currentTime;
    seq.forEach(function (q) {
      var o = actx.createOscillator(), g = actx.createGain();
      o.type = type === 'tap' ? 'square' : 'sine'; o.frequency.value = q[0];
      g.gain.setValueAtTime(type === 'tap' ? .025 : .07, t); g.gain.exponentialRampToValueAtTime(.0001, t + q[1]);
      o.connect(g); g.connect(actx.destination); o.start(t); o.stop(t + q[1] + .02); t += q[1] * .9;
    });
  } catch (e) {}
}

/* ============ Сообщения ============ */
function toast(title, text, kind, icon) {
  var box = $('#toasts'), el = document.createElement('div');
  el.className = 'toast ' + (kind || '');
  el.innerHTML = '<div class="ic">' + (icon || (kind === 'r' ? '!' : kind === 'o' ? '◆' : '✓')) + '</div><div><b>' + esc(title) + '</b><span>' + esc(text || '') + '</span></div>';
  box.appendChild(el);
  while (box.children.length > 3) box.removeChild(box.firstChild);
  $('#ledRed').classList.add('on');
  setTimeout(function () { el.classList.add('out'); }, 2800);
  setTimeout(function () { if (el.parentNode) el.parentNode.removeChild(el); if (!box.children.length) $('#ledRed').classList.remove('on'); }, 3100);
}

/* ============ Диалоги ============ */
function openModal(title, body, foot, size, focus) {
  var m = $('#modal');
  m.innerHTML = '<div class="dlg ' + (size || '') + '"><div class="dlg-in"><div class="whead"><h3>' + esc(title) + '</h3><button class="tb" data-act="closeModal">' + ico('cross') + '</button></div>' +
    '<div class="dlg-b">' + body + '</div>' + (foot ? '<div class="dlg-f">' + foot + '</div>' : '') + '</div></div>';
  m.classList.remove('hidden');
  if (focus) { var f = m.querySelector('input,textarea'); if (f) setTimeout(function () { f.focus(); }, 60); }
}
function closeModal() { var m = $('#modal'); m.classList.add('hidden'); m.innerHTML = ''; formCtx = null; }
function modalOpen() { return !$('#modal').classList.contains('hidden'); }
function field(f, v) {
  var val = v == null ? (f.def == null ? '' : f.def) : v, inp;
  if (f.type === 'textarea') inp = '<textarea name="' + f.k + '" placeholder="' + esc(f.ph || '') + '">' + esc(val) + '</textarea>';
  else if (f.type === 'select') inp = '<select name="' + f.k + '">' + f.opts.map(function (o) {
    var ov = Array.isArray(o) ? o[0] : o, ol = Array.isArray(o) ? o[1] : o;
    return '<option value="' + esc(ov) + '"' + (String(ov) === String(val) ? ' selected' : '') + '>' + esc(ol) + '</option>';
  }).join('') + '</select>';
  else inp = '<input name="' + f.k + '" type="' + (f.type || 'text') + '" value="' + esc(val) + '" placeholder="' + esc(f.ph || '') + '"' + (f.type === 'number' ? ' inputmode="numeric"' : '') + '>';
  return '<label' + (f.full ? ' class="full"' : '') + '>' + esc(f.label) + inp + '</label>';
}
var formCtx = null, confirmCb = null;
function openForm(title, fields, values, onSave, extra) {
  values = values || {};
  openModal(title, '<form class="form" id="frm" onsubmit="return false">' + fields.map(function (f) { return field(f, values[f.k]); }).join('') + '</form>',
    (extra || '') + '<button class="btn" data-act="closeModal">Отмена</button><button class="btn g" data-act="submitForm">Сохранить</button>', '', !values.__edit);
  formCtx = { fields: fields, onSave: onSave };
}
function submitForm() {
  if (!formCtx) return;
  var frm = $('#frm'), out = {}, bad = null;
  formCtx.fields.forEach(function (f) {
    var el = frm.elements[f.k], v = el ? el.value : '';
    v = f.type === 'number' ? (Number(v) || 0) : f.type === 'textarea' ? String(v).replace(/\s+$/, '') : String(v).trim();
    if (f.req && !v) bad = el; out[f.k] = v;
  });
  if (bad) { bad.focus(); bad.style.borderColor = 'var(--red)'; beep('err'); return; }
  var cb = formCtx.onSave; closeModal(); cb(out); save(); render(); beep('ok');
}
function confirmBox(title, text, ok, cb) {
  openModal(title, '<p style="margin:0;line-height:1.5">' + esc(text) + '</p>', '<button class="btn" data-act="closeModal">Отмена</button><button class="btn r" data-act="confirmOk">' + esc(ok) + '</button>', 'sm');
  confirmCb = cb;
}

/* ============ Каркас ============ */
function renderNav() {
  $('#nav').innerHTML = TABS.map(function (t, i) {
    return (i ? '<span class="tabsep">//</span>' : '') + '<button class="tab' + (ui.tab === t.id ? ' on' : '') + '" data-act="tab" data-id="' + t.id + '"><i></i><span>' + t.name + '</span></button>';
  }).join('');
}
function setPanes(l, r, layout) {
  $('.workspace').className = 'workspace ' + (layout || '');
  $('#paneL').innerHTML = l; $('#paneR').innerHTML = r;
}
function render() {
  renderNav();
  $('#hwSound').classList.toggle('muted', !S.settings.sound);
  var bl = $('#paneL .wbody'), br = $('#paneR .wbody'), sl = bl ? bl.scrollTop : 0, sr = br ? br.scrollTop : 0;
  var same = render._tab === ui.tab; render._tab = ui.tab;
  ({ tasks: rTasks, plan: rPlan, journal: rJournal, contacts: rContacts, ranks: rRanks, data: rData, help: rHelp })[ui.tab]();
  if (same) { var nl = $('#paneL .wbody'), nr = $('#paneR .wbody'); if (nl) nl.scrollTop = sl; if (nr && ui.keepR) nr.scrollTop = sr; }
  ui.keepR = false;
  bindMap();
  var s = $('#paneL .sel'); if (s && ui.scrollSel) { s.scrollIntoView({ block: 'nearest' }); } ui.scrollSel = false;
}
function whead(t) { return '<div class="whead"><h3>' + t + '</h3><span class="dots"></span></div>'; }
function filters(list, cur, act) {
  return '<div class="wfoot">' + list.map(function (f) { return '<button class="flt' + (cur === f[0] ? ' on' : '') + '" data-act="' + act + '" data-id="' + f[0] + '">' + f[1] + '</button>'; }).join('') + '</div>';
}
function empty(t) { return '<div class="empty">' + t + '</div>'; }
function hscroll() { return '<div class="hscroll"><i id="hsThumb"></i></div>'; }

/* ============ Карта ============ */
function mapHTML(o) {
  var W = 480, H = 250, svg = '<svg viewBox="0 0 ' + W + ' ' + H + '" preserveAspectRatio="xMidYMid slice">';
  svg += TERRAIN ? '<image href="' + TERRAIN + '" x="0" y="0" width="' + W + '" height="' + H + '" preserveAspectRatio="none"/>' : '<rect width="480" height="250" fill="#3a3833"/>';
  svg += '<path d="M0 214 Q110 205 210 222 T480 210" fill="none" stroke="#3e5566" stroke-width="3" opacity=".55"/>' +
    '<circle cx="358" cy="30" r="22" fill="none" stroke="#d04030" stroke-width=".8" stroke-dasharray="3 3" opacity=".7"/>';
  svg += ROADS.map(function (r) { var a = loc(r[0]), b = loc(r[1]); return '<line x1="' + a.x + '" y1="' + a.y + '" x2="' + b.x + '" y2="' + b.y + '" stroke="#77705e" stroke-width="1.6" opacity=".55"/>'; }).join('');
  if (o.route && o.route.length > 1) svg += '<polyline class="route" points="' + o.route.map(function (p) { var l = loc(p.loc); return l.x + ',' + l.y; }).join(' ') + '"/>';
  svg += LOCS.map(function (l) {
    var anchor = l.x > 370 ? 'end' : 'start', dx = l.x > 370 ? -7 : 7;
    return '<g class="loc" data-act="mapLoc" data-id="' + l.id + '"><circle cx="' + l.x + '" cy="' + l.y + '" r="13" fill="transparent"/><circle cx="' + l.x + '" cy="' + l.y + '" r="2" fill="#e8e8e8"/>' +
      '<text x="' + (l.x + dx) + '" y="' + (l.y + 4) + '" text-anchor="' + anchor + '">' + esc(l.name) + '</text></g>';
  }).join('');
  var seen = {};
  (o.marks || []).forEach(function (m) {
    var l = loc(m.loc), k = seen[l.id] = (seen[l.id] || 0) + 1, cx = l.x + 2 + (k - 1) * 11, cy = l.y - 13;
    if (m.sel) svg += '<circle class="ping" cx="' + cx + '" cy="' + cy + '" r="7"/>';
    svg += '<g transform="translate(' + (cx - (m.sel ? 9 : 7)) + ' ' + (cy - (m.sel ? 9 : 7)) + ') scale(' + (m.sel ? .9 : .7) + ')" style="pointer-events:none">' + (m.red ? TGT_RED : TGT) + '</g>';
  });
  (o.nums || []).forEach(function (p, i) {
    var l = loc(p.loc), k = seen[l.id] = (seen[l.id] || 0) + 1, cx = l.x - 8 - (k - 1) * 10, cy = l.y - 10;
    svg += '<circle cx="' + cx + '" cy="' + cy + '" r="5" fill="#e9a23b" stroke="#000" stroke-width=".6"/><text x="' + cx + '" y="' + (cy + 2.5) + '" text-anchor="middle" style="font:700 7px monospace;fill:#1a1200;pointer-events:none">' + (i + 1) + '</text>';
  });
  var me = loc(S.profile.loc);
  svg += '<g transform="translate(' + (me.x - 18) + ' ' + (me.y - 4) + ')" style="pointer-events:none"><circle r="6.5" fill="rgba(0,0,0,.55)" stroke="#e8e8e8" stroke-width="1.2"/><circle cy="-2.6" r="1.6" fill="#e8e8e8"/><path d="M-2.6 4l1-4.3h3.2l1 4.3M-1.2 0l-.6 2.6M1.2 0l.6 2.6" stroke="#e8e8e8" stroke-width="1" fill="none"/></g>';
  svg += '</svg>';
  return '<div class="map" id="map"><div class="mv" id="mv">' + svg + '</div>' + (o.info || '') + '<div class="map-title">Карта Зоны</div></div>';
}
function applyMap() {
  var mv = $('#mv'), m = $('#map'); if (!mv || !m) return;
  var w = m.clientWidth, h = m.clientHeight, z = ui.map.z;
  ui.map.x = Math.min(0, Math.max(w - w * z, ui.map.x)); ui.map.y = Math.min(0, Math.max(h - h * z, ui.map.y));
  mv.style.transform = 'translate(' + ui.map.x + 'px,' + ui.map.y + 'px) scale(' + z + ')';
  var th = $('#hsThumb'); if (th) { th.style.width = (100 / z) + '%'; th.style.left = (-ui.map.x / (w * z) * 100) + '%'; }
}
function zoomMap(f) {
  var m = $('#map'); if (!m) return;
  var w = m.clientWidth, h = m.clientHeight, z0 = ui.map.z, z1 = Math.max(1, Math.min(4, z0 * f));
  ui.map.x = w / 2 - (w / 2 - ui.map.x) * (z1 / z0); ui.map.y = h / 2 - (h / 2 - ui.map.y) * (z1 / z0); ui.map.z = z1; applyMap();
}
var drag = null, justDragged = 0;
function bindMap() {
  var m = $('#map'); if (!m) return;
  applyMap();
  m.addEventListener('pointerdown', function (e) { drag = { sx: e.clientX, sy: e.clientY, x: ui.map.x, y: ui.map.y, moved: false }; });
  m.addEventListener('pointermove', function (e) {
    if (!drag) return;
    var dx = e.clientX - drag.sx, dy = e.clientY - drag.sy;
    if (!drag.moved && Math.abs(dx) + Math.abs(dy) > 6) { drag.moved = true; try { m.setPointerCapture(e.pointerId); } catch (x) {} }
    if (drag.moved) { ui.map.x = drag.x + dx; ui.map.y = drag.y + dy; applyMap(); }
  });
  var end = function () { if (drag && drag.moved) justDragged = Date.now(); drag = null; };
  m.addEventListener('pointerup', end); m.addEventListener('pointercancel', end);
}
window.addEventListener('resize', function () { applyMap(); });
function mapTools() { return '<span class="sp"></span>' + tb('zoomIn', 'zin') + tb('zoomOut', 'zout') + tb('zoomFit', 'fit'); }

/* ============ Задачи ============ */
function rTasks() {
  var f = ui.taskFilter, cnt = { active: 0, done: 0, failed: 0 }, order = { high: 0, mid: 1, low: 2 };
  S.tasks.forEach(function (t) { cnt[t.status]++; });
  var list = S.tasks.filter(function (t) { return t.status === f; }).sort(function (a, b) {
    return f === 'active' ? (order[a.prio] - order[b.prio]) || (b.created - a.created) : (b.done || 0) - (a.done || 0);
  });
  if (!find(list, ui.sel.tasks)) ui.sel.tasks = list.length ? list[0].id : null;
  var L = whead('Задания') + '<div class="wbody"><div class="list">' + (list.length ? list.map(function (t) {
    var next = -1; t.steps.forEach(function (s, i) { if (next < 0 && !s.done) next = i; });
    return '<div class="task ' + t.status + (ui.sel.tasks === t.id ? ' sel' : '') + '" data-act="selTask" data-id="' + t.id + '" data-sel="' + t.id + '">' +
      '<div class="task-h"><div class="thumb ' + t.status + '" style="' + thumbStyle(t.loc) + '"><b></b></div><div class="task-t"><div class="ttl">' + esc(t.title) + '</div><div class="date">' + fmtDT(t.created) + '</div></div><div class="task-ico">' + SCROLLICO + '</div></div>' +
      (t.steps.length ? '<div class="steps">' + t.steps.map(function (s, i) {
        return '<div class="step' + (s.done ? ' done' : '') + '" data-act="step" data-id="' + t.id + '" data-i="' + i + '"><span class="c"></span><span>' + esc(s.t) + '</span>' +
          (t.status === 'active' && i === next ? '<span class="tgt">' + TGT + '</span>' : (s.done ? '' : '<span class="tgt">' + TGT_GREY + '</span>')) + '</div>';
      }).join('') + '</div>' : '') + '</div>';
  }).join('') : empty(f === 'active' ? 'Активных заданий нет.' : 'Здесь пока пусто.')) + '</div></div>' +
    filters([['active', 'Активные'], ['done', 'Выполненные'], ['failed', 'Проваленные']], f, 'taskFilter');

  var t = find(S.tasks, ui.sel.tasks), act = t && t.status === 'active', id = t ? ' data-id="' + t.id + '"' : '';
  var info = t ? '<div class="map-info" data-act="taskInfo"' + id + ' style="pointer-events:auto"><b>' + esc(t.title) + '</b><span>' + esc(locName(t.loc)) + ' · ' + money(t.reward) + ' · ' + PRIO[t.prio] + ' приоритет</span>' +
    (t.desc ? '<div style="margin-top:3px;color:#cfcfd3;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden">' + esc(t.desc) + '</div>' : '') + '</div>' : '';
  var marks = S.tasks.filter(function (x) { return x.status === 'active'; }).map(function (x) { return { loc: x.loc, sel: x.id === ui.sel.tasks, red: x.prio === 'high' && x.id !== ui.sel.tasks }; });
  var R = '<div class="wtool">' + tb('addTask', 'plus', 'Новое') + tb('doneTask', 'check', 'Сдать', 'g', id, !act) + tb('failTask', 'cross', 'Провал', 'r', id, !act) +
    tb('editTask', 'edit', '', '', id, !t) + tb('delTask', 'trash', '', '', id, !t) + mapTools() + '</div>' +
    '<div class="wbody" style="overflow:hidden">' + mapHTML({ marks: marks, info: info }) + '</div>' + hscroll();
  setPanes(L, R);
}
function taskFields() {
  return [
    { k: 'title', label: 'Название', req: true, full: true, ph: 'Например: Найти артефакт «Душа»' },
    { k: 'steps', label: 'Этапы — каждый с новой строки', type: 'textarea', full: true, ph: 'Поговорить с Волком\nНайти артефакт' },
    { k: 'desc', label: 'Описание', type: 'textarea', full: true },
    { k: 'loc', label: 'Локация', type: 'select', opts: LOCS.map(function (l) { return [l.id, l.name]; }), def: S.profile.loc },
    { k: 'prio', label: 'Приоритет', type: 'select', opts: [['high', 'Высокий'], ['mid', 'Средний'], ['low', 'Низкий']], def: 'mid' },
    { k: 'reward', label: 'Награда, RU', type: 'number', def: 0 }
  ];
}
function parseSteps(txt, old) {
  old = old || [];
  return String(txt || '').split('\n').map(function (s) { return s.trim(); }).filter(Boolean).map(function (s) {
    var o = old.filter(function (x) { return x.t === s; })[0]; return { t: s, done: o ? o.done : false };
  });
}
function addLog(title, text) { S.journal.push({ id: uid(), title: title, text: text || '', cat: 'Система', date: now() }); }
function gainXP(n) {
  var before = rankIdx(S.profile.xp); S.profile.xp = Math.max(0, S.profile.xp + n); var after = rankIdx(S.profile.xp);
  if (after > before) setTimeout(function () { beep('note'); toast('Новое звание', RANKS[after].name, 'o', '★'); addLog('Получено звание: ' + RANKS[after].name, RANKS[after].desc); save(); }, 900);
}

/* ============ План ============ */
function rPlan() {
  var plans = S.plans, active = plans.filter(function (p) { return !p.done; });
  if (!find(plans, ui.sel.plan)) ui.sel.plan = plans.length ? plans[0].id : null;
  var L = whead('План') + '<div class="wbody"><div class="list">' + (plans.length ? plans.map(function (p) {
    var n = active.indexOf(p) + 1;
    return '<div class="row' + (p.done ? ' done' : '') + (ui.sel.plan === p.id ? ' sel' : '') + '" data-act="selPlan" data-id="' + p.id + '" data-sel="' + p.id + '">' +
      '<span class="bullet ' + (p.done ? 'on' : 'o') + '">' + (p.done ? '' : n) + '</span><div class="txt"><div class="ttl">' + esc(p.title) + '</div><div class="sub">' + esc(locName(p.loc)) +
      (p.date ? ' · ' + fmtISO(p.date) : '') + (p.time ? ' ' + esc(p.time) : '') + '</div>' + (p.note ? '<div class="sub" style="font-family:var(--ui)">' + esc(p.note) + '</div>' : '') + '</div></div>';
  }).join('') : empty('Маршрут пуст. Нажми на локацию на карте.')) + '</div></div>' +
    '<div class="wfoot dim">Точек: <span class="yellow">' + active.length + '</span> / ' + plans.length + (plans.some(function (p) { return p.done; }) ? '<button class="flt" data-act="clearPlans" style="margin-left:auto">Убрать пройденные</button>' : '') + '</div>';
  var p = find(plans, ui.sel.plan), id = p ? ' data-id="' + p.id + '"' : '', i = p ? plans.indexOf(p) : -1;
  var R = '<div class="wtool">' + tb('addPlan', 'plus', 'Точка') + tb('donePlan', 'check', p && p.done ? 'Вернуть' : 'Пройдено', 'g', id, !p) +
    tb('movePlan', 'up', '', '', id + ' data-dir="-1"', !p || i === 0) + tb('movePlan', 'down', '', '', id + ' data-dir="1"', !p || i === plans.length - 1) +
    tb('editPlan', 'edit', '', '', id, !p) + tb('delPlan', 'trash', '', '', id, !p) + mapTools() + '</div>' +
    '<div class="wbody" style="overflow:hidden">' + mapHTML({ route: active, nums: active }) + '</div>' + hscroll();
  setPanes(L, R, 'wide');
}
function planFields() {
  return [
    { k: 'title', label: 'Название точки', req: true, full: true },
    { k: 'loc', label: 'Локация', type: 'select', opts: LOCS.map(function (l) { return [l.id, l.name]; }), def: S.profile.loc },
    { k: 'date', label: 'Дата', type: 'date', def: todayISO() }, { k: 'time', label: 'Время', type: 'time' },
    { k: 'note', label: 'Заметка', type: 'textarea', full: true }
  ];
}

/* ============ Журнал ============ */
function rJournal() {
  var q = ui.jq.toLowerCase(), f = ui.jf;
  var list = S.journal.filter(function (j) {
    return (!f || (f === 'sys' ? j.cat === 'Система' : j.cat !== 'Система')) && (!q || (j.title + ' ' + j.text).toLowerCase().indexOf(q) >= 0);
  }).sort(function (a, b) { return b.date - a.date; });
  if (!find(list, ui.sel.journal)) ui.sel.journal = list.length ? list[0].id : null;
  var L = whead('Журнал') + '<div class="wbody"><input class="search" id="jq" placeholder="Поиск по журналу…" value="' + esc(ui.jq) + '" style="width:100%;margin:2px 0 4px;padding:3px 7px;border:1px solid #4a4b52;background:#0b0b0d;color:#eee;font:inherit;outline:none"><div class="list">' +
    (list.length ? list.map(function (j) {
      return '<div class="row' + (ui.sel.journal === j.id ? ' sel' : '') + '" data-act="selJournal" data-id="' + j.id + '" data-sel="' + j.id + '"><span class="bullet' + (j.cat === 'Система' ? '' : ' on') + '"></span>' +
        '<div class="txt"><div class="ttl">' + esc(j.title) + '</div><div class="sub">' + fmtDT(j.date) + ' · ' + esc(j.cat) + '</div></div></div>';
    }).join('') : empty(q || f ? 'Ничего не найдено.' : 'Журнал пуст.')) + '</div></div>' +
    filters([['', 'Все'], ['own', 'Записи'], ['sys', 'Система']], f, 'jFilter');
  var j = find(S.journal, ui.sel.journal), id = j ? ' data-id="' + j.id + '"' : '';
  var R = '<div class="wtool">' + tb('addJournal', 'plus', 'Запись') + tb('editJournal', 'edit', 'Изменить', '', id, !j) + tb('delJournal', 'trash', '', '', id, !j) + '<span class="sp"></span></div>' +
    '<div class="wbody">' + (j ? '<div class="doc"><h2>' + esc(j.title) + '</h2><div class="meta">' + fmtDT(j.date) + ' · ' + esc(j.cat) + '</div><div class="text' + (j.text ? '' : ' dim') + '">' + (esc(j.text) || 'Пустая запись.') + '</div></div>' : empty('Выбери запись слева.')) + '</div>';
  setPanes(L, R);
}
function journalFields() {
  return [{ k: 'title', label: 'Заголовок', req: true, full: true }, { k: 'cat', label: 'Категория', type: 'select', opts: JCATS, def: 'Событие' }, { k: 'text', label: 'Текст', type: 'textarea', full: true }];
}

/* ============ Контакты ============ */
function rContacts() {
  var r = ui.crel;
  var list = S.contacts.filter(function (c) { return !r || c.rel === r; }).sort(function (a, b) { return a.name.localeCompare(b.name, 'ru'); });
  if (!find(list, ui.sel.contacts)) ui.sel.contacts = list.length ? list[0].id : null;
  var L = whead('Контакты') + '<div class="wbody"><div class="list">' + (list.length ? list.map(function (c) {
    return '<div class="row' + (ui.sel.contacts === c.id ? ' sel' : '') + '" data-act="selContact" data-id="' + c.id + '" data-sel="' + c.id + '">' + portrait(c.name, c.rel) +
      '<div class="txt"><div class="ttl">' + esc(c.name) + '</div><div class="sub">' + esc(c.faction) + ' · ' + esc(c.role) + '</div><div class="sub rel-' + c.rel + '">' + RELS[c.rel] + '</div></div></div>';
  }).join('') : empty('Никого нет.')) + '</div></div>' + filters([['', 'Все'], ['friend', 'Друзья'], ['neutral', 'Нейтралы'], ['enemy', 'Враги']], r, 'crel');
  var c = find(S.contacts, ui.sel.contacts), id = c ? ' data-id="' + c.id + '"' : '';
  var R = '<div class="wtool">' + tb('addContact', 'plus', 'Контакт') + tb('editContact', 'edit', 'Изменить', '', id, !c) + tb('delContact', 'trash', '', '', id, !c) + '<span class="sp"></span></div>' +
    '<div class="wbody">' + (c ? '<div class="doc"><div class="dossier">' + portrait(c.name, c.rel + ' big') + '<div style="flex:1;min-width:0"><h2>' + esc(c.name) + '</h2>' +
      '<dl class="kv"><dt>Группировка</dt><dd>' + esc(c.faction) + '</dd><dt>Род занятий</dt><dd>' + esc(c.role) + '</dd><dt>Отношение</dt><dd class="rel-' + c.rel + '">' + RELS[c.rel] + '</dd>' +
      '<dt>Где искать</dt><dd>' + esc(locName(c.loc)) + '</dd><dt>Группировка к тебе</dt><dd class="' + relCls(S.profile.rel[c.faction] || 0) + '">' + relLabel(S.profile.rel[c.faction] || 0) + '</dd></dl></div></div>' +
      '<div class="sect">Заметки</div><div class="text' + (c.note ? '' : ' dim') + '">' + (esc(c.note) || 'Заметок нет.') + '</div></div>' : empty('Выбери контакт слева.')) + '</div>';
  setPanes(L, R);
}
function contactFields() {
  return [
    { k: 'name', label: 'Имя / позывной', req: true },
    { k: 'rel', label: 'Отношение', type: 'select', opts: [['friend', 'Друг'], ['neutral', 'Нейтрал'], ['enemy', 'Враг']], def: 'neutral' },
    { k: 'faction', label: 'Группировка', type: 'select', opts: FACTIONS, def: 'Одиночки' },
    { k: 'role', label: 'Род занятий', type: 'select', opts: ROLES, def: 'Сталкер' },
    { k: 'loc', label: 'Где искать', type: 'select', opts: LOCS.map(function (l) { return [l.id, l.name]; }), def: S.profile.loc },
    { k: 'note', label: 'Заметки', type: 'textarea', full: true }
  ];
}

/* ============ Ранги ============ */
function rRanks() {
  var p = S.profile, ri = rankIdx(p.xp), next = RANKS[ri + 1];
  var rating = NPC_RATING.map(function (n) { return { n: n[0], f: n[1], xp: n[2] }; });
  rating.push({ n: p.callsign, f: p.faction, xp: p.xp, me: true });
  rating.sort(function (a, b) { return b.xp - a.xp; });
  var L = whead('Рейтинг') + '<div class="wbody rating"><div class="list">' + rating.map(function (r, i) {
    return '<div class="row' + (r.me ? ' me sel' : '') + '"' + (r.me ? ' data-sel="me"' : '') + '><span class="num">' + (i + 1) + '</span>' + portrait(r.n, '') +
      '<div class="txt"><div class="ttl">' + esc(r.n) + '</div><div class="sub">' + esc(r.f) + ' · ' + RANKS[rankIdx(r.xp)].name + '</div></div><span class="meta">' + r.xp + '</span></div>';
  }).join('') + '</div></div>';
  var pct = next ? Math.round((p.xp - RANKS[ri].xp) / (next.xp - RANKS[ri].xp) * 100) : 100;
  var R = '<div class="wtool">' + tb('editProfile', 'edit', 'Личное дело') + '<span class="sp"></span></div><div class="wbody"><div class="doc">' +
    '<div class="dossier">' + portrait(p.callsign + '!', 'big friend') + '<div style="flex:1;min-width:0"><h2>' + esc(p.callsign) + '</h2>' +
    '<dl class="kv"><dt>Звание</dt><dd class="orange">' + RANKS[ri].name + '</dd><dt>Группировка</dt><dd>' + esc(p.faction) + '</dd><dt>Деньги</dt><dd class="mono">' + money(p.money) + '</dd>' +
    '<dt>Репутация</dt><dd class="' + (p.rep >= 25 ? 'green' : p.rep > -25 ? 'yellow' : 'red') + '">' + repLabel(p.rep) + ' (' + (p.rep > 0 ? '+' : '') + p.rep + ')</dd></dl>' +
    '<div class="dim" style="font-size:.85em;display:flex;justify-content:space-between"><span>Опыт</span><span class="mono">' + p.xp + (next ? ' / ' + next.xp : ' · MAX') + '</span></div><div class="bar"><i style="width:' + pct + '%"></i></div></div></div>' +
    '<div class="sect">Звания</div><div class="rungs">' + RANKS.map(function (r, i) {
      return '<div class="rung' + (i < ri ? ' got' : '') + (i === ri ? ' cur' : '') + '"><b>' + r.ico + '</b><span style="flex:1">' + r.name + ' — ' + r.desc + '</span><span class="mono">' + r.xp + '</span></div>';
    }).join('') + '</div><div class="sect">Отношения группировок</div>' + FACTIONS.map(function (f) {
      var v = p.rel[f] || 0;
      return '<div class="fac"><span>' + f + '</span><input type="range" min="-100" max="100" step="5" value="' + v + '" data-fac="' + esc(f) + '"><span class="st ' + relCls(v) + '">' + relLabel(v) + '</span></div>';
    }).join('') + '</div></div>';
  setPanes(L, R, 'half');
}

/* ============ Данные ============ */
function rData() {
  var t = S.tasks, c = S.contacts, days = Math.max(1, Math.ceil((now() - S.created) / 864e5)), size = 0;
  try { size = (localStorage.getItem(KEY) || '').length; } catch (e) {}
  var cnt = function (a, f) { return a.filter(f).length; };
  var rows = [['Дней в Зоне', days], ['Активных заданий', cnt(t, function (x) { return x.status === 'active'; })], ['Выполнено заданий', cnt(t, function (x) { return x.status === 'done'; })],
    ['Провалено заданий', cnt(t, function (x) { return x.status === 'failed'; })], ['Точек маршрута', S.plans.length], ['Записей в журнале', S.journal.length],
    ['Контактов', c.length], ['Друзей / врагов', cnt(c, function (x) { return x.rel === 'friend'; }) + ' / ' + cnt(c, function (x) { return x.rel === 'enemy'; })],
    ['Опыт', S.profile.xp], ['На счету', money(S.profile.money)], ['Звание', RANKS[rankIdx(S.profile.xp)].name], ['Занято памяти', (size / 1024).toFixed(1) + ' КБ']];
  var L = whead('Статистика') + '<div class="wbody">' + rows.map(function (r) { return '<div class="stat"><span>' + r[0] + '</span><b>' + r[1] + '</b></div>'; }).join('') + '</div>';
  var tg = function (k, l) { return '<div class="toggle" data-act="toggle" data-id="' + k + '"><span>' + l + '</span><span class="check' + (S.settings[k] ? ' on' : '') + '"></span></div>'; };
  var R = '<div class="wtool"><span style="padding:0 6px;color:#d0d0d4">Резервные копии и настройки</span><span class="sp"></span></div><div class="wbody"><div class="doc">' +
    '<div class="sect">Резервная копия</div><div class="btns"><button class="btn" data-act="exportFile">Сохранить в файл</button><button class="btn" data-act="exportShare">Поделиться</button>' +
    '<button class="btn" data-act="importFile">Загрузить из файла</button><button class="btn" data-act="importPaste">Вставить текст</button>' +
    '<button class="btn" data-act="exportCopy">Копировать</button><button class="btn r" data-act="resetAll">Сброс КПК</button></div>' +
    '<div class="sect">Настройки</div>' + tg('sound', 'Звуки интерфейса') + tg('vibro', 'Вибрация') + tg('boot', 'Заставка при запуске') + '</div></div>';
  setPanes(L, R, 'half');
}
function exportText() { return JSON.stringify({ app: 'PDA-STALKER', version: 3, exported: new Date().toISOString(), data: S }, null, 1); }
function exportName() { var d = new Date(); return 'pda-stalker-' + d.getFullYear() + pad(d.getMonth() + 1) + pad(d.getDate()) + '-' + pad(d.getHours()) + pad(d.getMinutes()) + '.json'; }
function doImport(txt) {
  var o; try { o = JSON.parse(txt); } catch (e) { beep('err'); toast('Ошибка', 'Файл повреждён', 'r'); return; }
  var data = o && o.app === 'PDA-STALKER' ? o.data : (o && o.tasks ? o : null);
  if (!data) { beep('err'); toast('Ошибка', 'Это не резервная копия КПК', 'r'); return; }
  confirmBox('Восстановление', 'Текущие записи будут заменены копией (' + (data.tasks || []).length + ' заданий, ' + (data.journal || []).length + ' записей, ' + (data.contacts || []).length + ' контактов).', 'Восстановить', function () {
    S = normalize(data); ui.sel = {}; toast('Данные восстановлены', 'Копия загружена');
  });
}
window.pdaOnImport = function (txt) { if (txt == null) toast('Ошибка', 'Не удалось прочитать файл', 'r'); else doImport(txt); };
window.pdaOnSaved = function (ok) { if (ok) { beep('ok'); toast('Сохранено', 'Резервная копия записана'); } else toast('Ошибка', 'Не удалось сохранить', 'r'); };

/* ============ Справка ============ */
function rHelp() {
  var cur = HELP.filter(function (h) { return h.id === ui.help; })[0] || HELP[0];
  var L = whead('Справка') + '<div class="wbody"><div class="list">' + HELP.map(function (h) {
    return '<div class="row' + (h.id === cur.id ? ' sel' : '') + '" data-act="selHelp" data-id="' + h.id + '" data-sel="' + h.id + '"><span class="bullet' + (h.id === cur.id ? ' on' : '') + '"></span><div class="txt"><div class="ttl">' + h.t + '</div></div></div>';
  }).join('') + '</div></div>';
  var R = '<div class="wtool"><span style="padding:0 6px;color:#d0d0d4">' + cur.t + '</span><span class="sp"></span></div><div class="wbody"><div class="doc help">' + cur.h + '</div></div>';
  setPanes(L, R);
}

/* ============ Действия ============ */
function tabIdx() { for (var i = 0; i < TABS.length; i++) if (TABS[i].id === ui.tab) return i; return 0; }
function goTab(id) { if (ui.tab !== id) { ui.tab = id; render(); } }
function moveSel(dir) {
  var els = Array.prototype.slice.call(document.querySelectorAll('#paneL [data-sel]'));
  if (!els.length) return;
  var key = { tasks: 'tasks', plan: 'plan', journal: 'journal', contacts: 'contacts', help: 'help' }[ui.tab];
  if (!key) { var b = $('#paneL .wbody'); if (b) b.scrollTop += dir * 60; return; }
  var cur = ui.tab === 'help' ? ui.help : ui.sel[key];
  var i = els.findIndex(function (e) { return e.getAttribute('data-sel') === cur; }), j = Math.max(0, Math.min(els.length - 1, i + dir));
  var id = els[j].getAttribute('data-sel');
  if (ui.tab === 'help') ui.help = id; else ui.sel[key] = id;
  ui.scrollSel = true; render();
}
var A = {
  tab: function (d) { goTab(d.id); },
  closeModal: closeModal, submitForm: submitForm,
  confirmOk: function () { var cb = confirmCb; confirmCb = null; closeModal(); if (cb) cb(); save(); render(); },
  zoomIn: function () { zoomMap(1.5); }, zoomOut: function () { zoomMap(1 / 1.5); }, zoomFit: function () { ui.map = { z: 1, x: 0, y: 0 }; applyMap(); },

  taskFilter: function (d) { ui.taskFilter = d.id; render(); },
  selTask: function (d) { if (ui.sel.tasks !== d.id) { ui.sel.tasks = d.id; render(); } },
  step: function (d) {
    var t = find(S.tasks, d.id); if (!t) return;
    ui.sel.tasks = t.id;
    if (t.status !== 'active') { render(); return; }
    var s = t.steps[Number(d.i)]; s.done = !s.done; save(); render(); beep(s.done ? 'ok' : 'tap');
    if (s.done && t.steps.every(function (x) { return x.done; })) toast('Все этапы выполнены', 'Задание можно сдать: «' + t.title + '»', 'o', '◆');
  },
  taskInfo: function (d) {
    var t = find(S.tasks, d.id); if (!t) return;
    openModal(t.title, '<div class="doc"><dl class="kv"><dt>Локация</dt><dd>' + esc(locName(t.loc)) + '</dd><dt>Приоритет</dt><dd>' + PRIO[t.prio] + '</dd><dt>Награда</dt><dd class="orange mono">' + money(t.reward) + '</dd>' +
      '<dt>Опыт</dt><dd class="green mono">+' + XP_BY_PRIO[t.prio] + '</dd><dt>Получено</dt><dd class="mono">' + fmtDT(t.created) + '</dd>' + (t.done ? '<dt>Закрыто</dt><dd class="mono">' + fmtDT(t.done) + '</dd>' : '') + '</dl>' +
      '<div class="text' + (t.desc ? '' : ' dim') + '">' + (esc(t.desc) || 'Без описания.') + '</div></div>', '<button class="btn" data-act="closeModal">Закрыть</button>');
  },
  addTask: function () {
    openForm('Новое задание', taskFields(), {}, function (v) {
      var t = { id: uid(), title: v.title, desc: v.desc, loc: v.loc, prio: v.prio, reward: v.reward, steps: parseSteps(v.steps), status: 'active', created: now() };
      S.tasks.push(t); ui.sel.tasks = t.id; ui.taskFilter = 'active'; addLog('Получено задание: ' + v.title, v.desc);
      setTimeout(function () { beep('note'); toast('Новое задание', v.title, 'o', '◆'); }, 150);
    });
  },
  editTask: function (d) {
    var t = find(S.tasks, d.id); if (!t) return;
    openForm('Изменить задание', taskFields(), Object.assign({ __edit: 1 }, t, { steps: t.steps.map(function (s) { return s.t; }).join('\n') }), function (v) {
      t.title = v.title; t.desc = v.desc; t.loc = v.loc; t.prio = v.prio; t.reward = v.reward; t.steps = parseSteps(v.steps, t.steps);
    });
  },
  doneTask: function (d) {
    var t = find(S.tasks, d.id); if (!t || t.status !== 'active') return;
    var xp = XP_BY_PRIO[t.prio] || 50;
    t.status = 'done'; t.done = now(); t.steps.forEach(function (s) { s.done = true; });
    S.profile.money += Number(t.reward) || 0; S.profile.rep = Math.min(100, S.profile.rep + 5);
    addLog('Выполнено задание: ' + t.title, 'Награда: ' + money(t.reward) + ', опыт +' + xp);
    gainXP(xp); save(); render(); beep('ok'); toast('Задание выполнено', '+' + xp + ' опыта' + (t.reward ? ', +' + money(t.reward) : ''));
  },
  failTask: function (d) {
    var t = find(S.tasks, d.id); if (!t) return;
    confirmBox('Провал задания', '«' + t.title + '» будет отмечено как проваленное. Репутация −10.', 'Провалить', function () {
      t.status = 'failed'; t.done = now(); S.profile.rep = Math.max(-100, S.profile.rep - 10); addLog('Провалено задание: ' + t.title); beep('err'); toast('Задание провалено', t.title, 'r');
    });
  },
  delTask: function (d) { var t = find(S.tasks, d.id); if (t) confirmBox('Удалить задание', '«' + t.title + '» будет удалено.', 'Удалить', function () { S.tasks = S.tasks.filter(function (x) { return x.id !== d.id; }); }); },

  mapLoc: function (d) {
    if (Date.now() - justDragged < 350) return;
    var l = loc(d.id), here = S.profile.loc === l.id;
    var list = function (a, f) { return a.length ? a.map(f).join(', ') : '<span class="dim">нет</span>'; };
    openModal(l.name, '<dl class="kv"><dt>Задания</dt><dd>' + list(S.tasks.filter(function (t) { return t.loc === l.id && t.status === 'active'; }), function (t) { return esc(t.title); }) + '</dd>' +
      '<dt>Точки маршрута</dt><dd>' + list(S.plans.filter(function (p) { return p.loc === l.id && !p.done; }), function (p) { return esc(p.title); }) + '</dd>' +
      '<dt>Контакты</dt><dd>' + list(S.contacts.filter(function (c) { return c.loc === l.id; }), function (c) { return esc(c.name); }) + '</dd></dl>',
      '<button class="btn" data-act="setHere" data-id="' + l.id + '"' + (here ? ' disabled style="opacity:.4"' : '') + '>Я здесь</button><button class="btn g" data-act="addPlan" data-loc="' + l.id + '">+ Точка маршрута</button>', 'sm');
  },
  setHere: function (d) { S.profile.loc = d.id; closeModal(); addLog('Переход: ' + locName(d.id)); save(); render(); beep('ok'); toast('Местоположение', locName(d.id)); },
  selPlan: function (d) { if (ui.sel.plan !== d.id) { ui.sel.plan = d.id; render(); } },
  addPlan: function (d) {
    var pre = d && d.loc ? { loc: d.loc, title: locName(d.loc) } : {};
    openForm('Новая точка маршрута', planFields(), pre, function (v) { var p = Object.assign({ id: uid(), done: false }, v); S.plans.push(p); ui.sel.plan = p.id; });
  },
  editPlan: function (d) { var p = find(S.plans, d.id); if (p) openForm('Точка маршрута', planFields(), Object.assign({ __edit: 1 }, p), function (v) { Object.assign(p, v); }); },
  delPlan: function (d) { var p = find(S.plans, d.id); if (p) confirmBox('Удалить точку', '«' + p.title + '» будет удалена из маршрута.', 'Удалить', function () { S.plans = S.plans.filter(function (x) { return x.id !== d.id; }); }); },
  movePlan: function (d) {
    var i = S.plans.findIndex(function (p) { return p.id === d.id; }), j = i + Number(d.dir);
    if (i < 0 || j < 0 || j >= S.plans.length) return;
    var tmp = S.plans[i]; S.plans[i] = S.plans[j]; S.plans[j] = tmp; save(); render();
  },
  donePlan: function (d) {
    var p = find(S.plans, d.id); if (!p) return; p.done = !p.done;
    if (p.done) { S.profile.loc = p.loc; addLog('Точка маршрута пройдена: ' + p.title, locName(p.loc)); toast('Точка пройдена', p.title); }
    save(); render();
  },
  clearPlans: function () { S.plans = S.plans.filter(function (p) { return !p.done; }); save(); render(); },

  jFilter: function (d) { ui.jf = d.id; render(); },
  selJournal: function (d) { if (ui.sel.journal !== d.id) { ui.sel.journal = d.id; render(); } },
  addJournal: function () { openForm('Новая запись', journalFields(), {}, function (v) { var j = Object.assign({ id: uid(), date: now() }, v); S.journal.push(j); ui.sel.journal = j.id; ui.jq = ''; ui.jf = ''; }); },
  editJournal: function (d) { var j = find(S.journal, d.id); if (j) openForm('Изменить запись', journalFields(), Object.assign({ __edit: 1 }, j), function (v) { Object.assign(j, v); }); },
  delJournal: function (d) { confirmBox('Удалить запись', 'Запись будет удалена из журнала.', 'Удалить', function () { S.journal = S.journal.filter(function (x) { return x.id !== d.id; }); }); },

  crel: function (d) { ui.crel = d.id; render(); },
  selContact: function (d) { if (ui.sel.contacts !== d.id) { ui.sel.contacts = d.id; render(); } },
  addContact: function () { openForm('Новый контакт', contactFields(), {}, function (v) { var c = Object.assign({ id: uid() }, v); S.contacts.push(c); ui.sel.contacts = c.id; ui.crel = ''; toast('Контакт добавлен', v.name); }); },
  editContact: function (d) { var c = find(S.contacts, d.id); if (c) openForm('Изменить контакт', contactFields(), Object.assign({ __edit: 1 }, c), function (v) { Object.assign(c, v); }); },
  delContact: function (d) { var c = find(S.contacts, d.id); if (c) confirmBox('Удалить контакт', c.name + ' будет удалён из КПК.', 'Удалить', function () { S.contacts = S.contacts.filter(function (x) { return x.id !== d.id; }); }); },

  editProfile: function () {
    openForm('Личное дело', [{ k: 'callsign', label: 'Позывной', req: true }, { k: 'faction', label: 'Группировка', type: 'select', opts: FACTIONS },
      { k: 'money', label: 'Деньги, RU', type: 'number' }, { k: 'loc', label: 'Текущая локация', type: 'select', opts: LOCS.map(function (l) { return [l.id, l.name]; }) }],
      Object.assign({ __edit: 1 }, S.profile), function (v) { Object.assign(S.profile, v); });
  },

  toggle: function (d) { S.settings[d.id] = !S.settings[d.id]; save(); render(); },
  exportFile: function () {
    var txt = exportText(), name = exportName();
    if (NATIVE) { NATIVE.saveFile(name, txt); return; }
    var a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([txt], { type: 'application/json' })); a.download = name; a.click();
    setTimeout(function () { URL.revokeObjectURL(a.href); }, 2000); window.pdaOnSaved(true);
  },
  exportShare: function () { var txt = exportText(); if (NATIVE) NATIVE.share(txt); else if (navigator.share) navigator.share({ text: txt }).catch(function () {}); else A.exportCopy(); },
  exportCopy: function () { var txt = exportText(); if (NATIVE) NATIVE.copy(txt); else if (navigator.clipboard) navigator.clipboard.writeText(txt).catch(function () {}); beep('ok'); toast('Скопировано', 'Копия в буфере обмена'); },
  importFile: function () { if (NATIVE) NATIVE.openFile(); else $('#fileInput').click(); },
  importPaste: function () {
    openModal('Вставить резервную копию', '<textarea class="paste" id="pasteTxt" placeholder="Вставь сюда текст резервной копии (JSON)…"></textarea>',
      '<button class="btn" data-act="closeModal">Отмена</button><button class="btn g" data-act="pasteGo">Загрузить</button>');
  },
  pasteGo: function () { var t = $('#pasteTxt').value; closeModal(); doImport(t); },
  resetAll: function () {
    confirmBox('Сброс КПК', 'Все задания, маршруты, записи, контакты и прогресс будут стёрты. Сначала сохрани резервную копию.', 'Стереть всё', function () {
      var s = S.settings; S = seed(); S.tasks = []; S.plans = []; S.journal = []; S.contacts = []; S.settings = s; ui.sel = {}; toast('КПК сброшен', 'Память очищена', 'o');
    });
  },
  selHelp: function (d) { ui.help = d.id; render(); },

  hwBack: function () { if (!window.pdaBack()) toast('КПК', 'Ты на главном экране', 'o', '◆'); },
  hwNew: function () {
    if (modalOpen()) return;
    var m = { tasks: 'addTask', plan: 'addPlan', journal: 'addJournal', contacts: 'addContact', ranks: 'editProfile', data: 'exportFile' }[ui.tab];
    if (m) A[m]({});
  },
  hwSound: function () { S.settings.sound = !S.settings.sound; save(); $('#hwSound').classList.toggle('muted', !S.settings.sound); if (S.settings.sound) beep('ok'); if (ui.tab === 'data') render(); },
  hwPower: function () { powerOff(); },
  dpUp: function () { if (!modalOpen()) moveSel(-1); }, dpDown: function () { if (!modalOpen()) moveSel(1); },
  dpLeft: function () { if (!modalOpen()) goTab(TABS[(tabIdx() + TABS.length - 1) % TABS.length].id); },
  dpRight: function () { if (!modalOpen()) goTab(TABS[(tabIdx() + 1) % TABS.length].id); },
  dpOk: function () {
    if (modalOpen()) { if (formCtx) submitForm(); else if (confirmCb) A.confirmOk(); else closeModal(); return; }
    if (ui.tab === 'tasks') {
      var t = find(S.tasks, ui.sel.tasks); if (!t || t.status !== 'active') return;
      var i = t.steps.findIndex(function (s) { return !s.done; });
      if (i >= 0) A.step({ id: t.id, i: i }); else A.doneTask({ id: t.id });
    } else if (ui.tab === 'plan' && ui.sel.plan) A.donePlan({ id: ui.sel.plan });
    else if (ui.tab === 'journal' && ui.sel.journal) A.editJournal({ id: ui.sel.journal });
    else if (ui.tab === 'contacts' && ui.sel.contacts) A.editContact({ id: ui.sel.contacts });
    else if (ui.tab === 'ranks') A.editProfile();
  }
};

document.addEventListener('click', function (e) {
  var el = e.target.closest('[data-act]');
  if (!el || el.disabled) return;
  var act = el.getAttribute('data-act');
  if (!A[act]) return;
  if (act === 'step' || act === 'selTask') e.stopPropagation();
  if (['doneTask', 'submitForm', 'confirmOk', 'step'].indexOf(act) < 0) beep('tap');
  A[act](el.dataset);
}, true);
$('#modal').addEventListener('click', function (e) { if (e.target.id === 'modal') closeModal(); });
document.addEventListener('input', function (e) {
  var t = e.target;
  if (t.id === 'jq') { ui.jq = t.value; var pos = t.selectionStart; render(); var n = $('#jq'); if (n) { n.focus(); try { n.setSelectionRange(pos, pos); } catch (x) {} } }
  else if (t.dataset && t.dataset.fac) { var v = Number(t.value); S.profile.rel[t.dataset.fac] = v; var s = t.nextElementSibling; s.className = 'st ' + relCls(v); s.textContent = relLabel(v); }
});
document.addEventListener('change', function (e) {
  var t = e.target;
  if (t.dataset && t.dataset.fac) save();
  else if (t.id === 'fileInput' && t.files && t.files[0]) { var r = new FileReader(); r.onload = function () { doImport(String(r.result)); }; r.readAsText(t.files[0]); t.value = ''; }
});
document.addEventListener('keydown', function (e) {
  if (e.key === 'Escape') window.pdaBack();
  if (e.key === 'Enter' && formCtx && e.target.tagName === 'INPUT') { e.preventDefault(); submitForm(); }
});

/* ============ Назад ============ */
window.pdaBack = function () {
  var b = $('#boot');
  if (!b.classList.contains('hidden')) { if (b.dataset.off) return false; finishBoot(); return true; }
  if (modalOpen()) { closeModal(); beep('tap'); return true; }
  if (ui.tab !== 'tasks') { ui.tab = 'tasks'; render(); beep('tap'); return true; }
  return false;
};
window.pdaPause = function () { save(); };

/* ============ Часы ============ */
function tick() { var d = new Date(); $('#clock').textContent = pad(d.getHours()) + ':' + pad(d.getMinutes()) + ' ' + fmtD(d.getTime()); }

/* ============ Загрузка / выключение ============ */
var bootTimer = null;
function startBoot(force) {
  var b = $('#boot');
  if (!force && !S.settings.boot) { b.classList.add('hidden'); return; }
  b.classList.remove('hidden', 'off'); delete b.dataset.off;
  b.innerHTML = '<div class="t">S.T.A.L.K.E.R.</div><div class="s">ПЕРСОНАЛЬНЫЙ КПК · v3.0</div><div class="bar"><i id="bootBar" style="width:0"></i></div><div class="l" id="bootLog"></div>';
  var lines = ['Проверка памяти…', 'Модуль связи…', 'Детектор аномалий…', 'Загрузка карты Зоны…', 'Профиль: ' + S.profile.callsign, 'Добро пожаловать в Зону'];
  var i = 0; beep('boot');
  bootTimer = setInterval(function () {
    if (i < lines.length) { $('#bootLog').textContent = lines[i]; i++; $('#bootBar').style.width = Math.round(i / lines.length * 100) + '%'; }
    else finishBoot();
  }, 260);
}
function finishBoot() {
  clearInterval(bootTimer); bootTimer = null;
  var b = $('#boot'); if (b.classList.contains('hidden')) return;
  delete b.dataset.off; $('#pda').classList.remove('powered'); $('#ledGreen').classList.add('on');
  b.classList.add('off');
  setTimeout(function () { b.classList.add('hidden'); b.classList.remove('off'); b.innerHTML = ''; applyMap(); }, 400);
  var n = S.tasks.filter(function (t) { return t.status === 'active'; }).length;
  if (n) setTimeout(function () { beep('note'); toast('Активных заданий: ' + n, 'Проверь раздел «Задачи»', 'o', '◆'); }, 650);
}
function powerOff() {
  closeModal(); save(); clearInterval(bootTimer);
  var b = $('#boot');
  $('#pda').classList.add('powered'); $('#ledGreen').classList.remove('on');
  b.classList.remove('hidden', 'off'); b.dataset.off = '1';
  b.innerHTML = '<div class="s">КПК ВЫКЛЮЧЕН</div><div class="l">коснись экрана, чтобы включить</div>';
}
$('#boot').addEventListener('click', function (e) {
  e.stopPropagation();
  if ($('#boot').dataset.off) startBoot(true); else finishBoot();
});

/* ============ Старт ============ */
load();
makeTerrain();
var h = (location.hash || '').slice(1); if (TABS.some(function (t) { return t.id === h; })) ui.tab = h;
render(); tick(); setInterval(tick, 5000);
startBoot(false);
})();
